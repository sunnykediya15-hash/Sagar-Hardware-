# Sagar Hardware V15
सही Android project structure.
GitHub में extracted files upload करें। फिर Actions → Build Sagar Hardware APK → Run workflow.
Build सफल होने पर Artifacts में sagar-hardware-debug-apk से app-debug.apk मिलेगा.
ZIP को single file की तरह GitHub में upload न करें.
